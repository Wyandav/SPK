<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('form_validation');
    }

    public function index() {
        // Jika pengguna sudah login, arahkan ke halaman dashboard
        if ($this->session->userdata('logged_in')) {
            redirect('/');
        }
        
        // Validasi form login
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            // Tampilkan halaman login jika validasi gagal
            $this->load->view('login_view');
        } else {
            // Proses login
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            // Query ke database untuk mencari pengguna dengan username yang sesuai
            $query = $this->db->get_where('user', array('username' => $username));
            $user = $query->row_array();
            
            if ($user) {
                // Verifikasi password (gunakan password_verify() jika password di-hash)
                if ($password == $user['password']) { // Jika menggunakan password tanpa hash
                    // Simpan data pengguna ke session
                    $session_data = array(
                        'user_id' => $user['id'], // Sesuaikan dengan kolom ID pada tabel users
                        'username' => $user['username'],
                        'logged_in' => TRUE
                    );
                    $this->session->set_userdata($session_data);
                    
                    // Redirect ke halaman dashboard atau halaman lain setelah login berhasil
                    redirect('/');
                } else {
                    // Tampilkan pesan error jika password tidak sesuai
                    $data['error'] = 'Password salah.';
                    $this->load->view('login_view', $data);
                }
            } else {
                // Tampilkan pesan error jika username tidak ditemukan
                $data['error'] = 'Username tidak ditemukan.';
                $this->load->view('login_view', $data);
            }
        }
    }

    public function logout() {
        // Hapus data session dan redirect ke halaman login
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('logged_in');
        $this->session->sess_destroy();
        redirect('login');
    }

}
?>
