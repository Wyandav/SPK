<div class="carousel-item">
          <img src="<?php echo base_url('assets/img/logosmk.png') ?>" class="d-block w-100" alt="...">
        </div>
<div class="jumbotron">
    <h1>Welcome to SPK Guru SMK Muhammadiyah 1 YK</h1>
    <h3>Sistem Pendukung Keputusan sering disingkat dengan DSS (Decision Support System) merupakan bagian dari sistem informasi berbasis komputer untuk mendukung pengambilan keputusan dalam suatu organisasi atau perusahaan. </h3>

</div>
<!-- slider -->

<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="<?php echo base_url('assets/img/slide2smk.png') ?>" class="d-block w-100" alt="...">
        </div>
      </div>
    </div>
    <div class="jumbotron">
    <h6 class="text-uppercase fw-bold mb-6">
            Contact
          </h6>
          <p><i class="fas fa-home me-3"></i>  Jl. Nitikan Baru No.48, Sorosutan, Kec. Umbulharjo, Kota Yogyakarta, Daerah Istimewa Yogyakarta </p>
          <p>
            <i class="fas fa-envelope me-3"></i>
            smkmuhammadiyah1yk@co.id
                </div>
                </div>
            </div>
    </div>
    <br><br><br><br>
