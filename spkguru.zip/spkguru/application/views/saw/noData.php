<h1>
    <div class="alert alert-danger" role="alert">
        Data guru kosong, Harap mengisi data guru untuk menghitung rangking !
    </div>
</h1>