<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Admin SPK</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom styles untuk form */
        .login-form {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 50px;
        }
        .login-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-form label {
            font-weight: bold;
        }
        .login-form .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-form">
            <h2>Login</h2>
            <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
            <?php echo isset($error) ? '<div class="alert alert-danger">' . $error . '</div>' : ''; ?>

            <?php echo form_open('login'); ?>
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo set_value('username'); ?>">
                    <?php echo form_error('username', '<div class="error">', '</div>'); ?>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password">
                    <?php echo form_error('password', '<div class="error">', '</div>'); ?>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Login</button>
            <?php echo form_close(); ?>
        </div>
    </div>

    <!-- Bootstrap JS dan dependencies (opsional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
